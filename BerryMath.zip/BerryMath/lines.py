#!/usr/bin/env python
# encoding: utf-8

import os
import sys

directories = ["src", "include"]
types = [".cpp", ".hpp", ".c", ".h"]

root = os.path.abspath(sys.argv[0] + "/..")

lines = 0

for i in directories:
	path = os.path.join(root, i)
	for dirpath, dirnames, filenames in os.walk(path):
		for j in filenames:
			filepath = os.path.join(dirpath, j)
			file = open(filepath)
			content = file.read()
			lines += len(content.split("\n"))

print("line: " + str(lines))